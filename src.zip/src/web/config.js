const config = {
  apiUrl: 'http://localhost:3521'
};

export default config;